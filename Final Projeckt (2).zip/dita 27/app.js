function showMessage(){
    alert("This mesage is inside the functions")
}
showMessage()
function sum(number1,number2){
    return number1 + number2;
}
console.log(sum(25,5))